var webServiceUrl = "http://phonesrv-v.newleafsc.net:8098/";
var webServiceUrlSecure = "https://phonesrv-v.newleafsc.net:8498/";
