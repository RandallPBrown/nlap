var webServiceUrl = "http://phonesrv-v.newleafsc.net:8098/";
var webServiceUrlSecure = "http://phonesrv-v.newleafsc.net:8498/";
